package pkg2024_exam_q2;

public class MovieTicketData 
{
    public String movieName;
    public int numberOfTickets;
    public double ticketPrice;

    // constructor
    public MovieTicketData(String movieName, int numberOfTickets, double ticketPrice)
    {
        this.movieName = movieName;
        this.numberOfTickets = numberOfTickets;
        this.ticketPrice = ticketPrice;
    }
}
